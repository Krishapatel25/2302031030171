import urllib.request

for url in ("http://127.0.0.1:8000/health", "http://localhost:8000/health"):
    try:
        with urllib.request.urlopen(url, timeout=3) as r:
            print(url, r.status, r.read().decode())
    except Exception as e:
        print(url, "FAILED:", e)
