// Use Vite's same-origin proxy in development. This avoids browser CORS/fetch
// failures caused by localhost vs 127.0.0.1 mismatches.
const API_BASE = (import.meta.env.VITE_API_URL || "").replace(/\/$/, "");

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE}${path}`, options);
  } catch (err) {
    throw new Error(
      "Backend connection failed. Start FastAPI on http://127.0.0.1:8000 and keep this Vite app open on http://localhost:5173."
    );
  }

  const type = response.headers.get("content-type") || "";
  const data = type.includes("application/json")
    ? await response.json().catch(() => ({}))
    : { detail: await response.text().catch(() => "") };

  if (!response.ok) {
    throw new Error(data.detail || `API error (${response.status})`);
  }
  return data;
}

export function checkBackend() {
  return request("/health", { method: "GET" });
}

export function analyzeText(text, title = "") {
  return request("/api/analyze/text", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text, title }),
  });
}

export function analyzeFile(mode, file) {
  const form = new FormData();
  form.append("file", file);
  const endpoint = mode === "voice" ? "voice" : mode;
  return request(`/api/analyze/${endpoint}`, { method: "POST", body: form });
}

export function analyzeUrl(url) {
  return request("/api/analyze-url", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url }),
  });
}
