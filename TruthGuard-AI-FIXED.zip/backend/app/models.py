from functools import lru_cache
from transformers import pipeline
from .config import TEXT_MODEL, IMAGE_MODEL, VIDEO_MODEL, AUDIO_MODEL

@lru_cache(maxsize=1)
def text_detector():
    return pipeline("text-classification", model=TEXT_MODEL, truncation=True, top_k=2)

@lru_cache(maxsize=1)
def image_detector():
    return pipeline("image-classification", model=IMAGE_MODEL, trust_remote_code=True, top_k=None)

@lru_cache(maxsize=1)
def video_detector():
    return pipeline("video-classification", model=VIDEO_MODEL, trust_remote_code=True)

@lru_cache(maxsize=1)
def audio_detector():
    return pipeline("audio-classification", model=AUDIO_MODEL, top_k=None)
