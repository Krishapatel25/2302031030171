import {useState} from "react";
import {analyzeUrl} from "./api";

export default function URLScanner(){
  const [url,setUrl]=useState("");
  const [loading,setLoading]=useState(false);
  const [payload,setPayload]=useState(null);
  const [error,setError]=useState("");

  async function scan(){
    if(!url.trim()) return;
    setLoading(true); setError(""); setPayload(null);
    try { setPayload(await analyzeUrl(url.trim())); }
    catch(e){ setError(e.message || "Could not analyze URL."); }
    finally { setLoading(false); }
  }

  const result = payload?.result;
  const fetched = payload?.fetched;

  return <main className="url-scanner-page container">
    <div className="eyebrow">🔗 URL SCANNER</div>
    <h1>Check a real video, image, audio or article URL</h1>
    <p>
      YouTube links are downloaded and scanned as video. Direct image/video/audio URLs use the
      matching forensic model. Normal article pages are checked with the news model. Some
      login-only or JavaScript-only pages cannot be fetched automatically.
    </p>
    <div className="url-input-row">
      <input value={url} onChange={e=>setUrl(e.target.value)}
        onKeyDown={e=>e.key==="Enter"&&scan()}
        placeholder="https://youtube.com/watch?v=..."/>
      <button className="btn btn-primary" onClick={scan} disabled={loading}>
        {loading?"Analyzing...":"Fetch & Check"}
      </button>
    </div>

    {error && <div className="api-error">{error}<br/><small>If the message says backend connection failed, run START_TRUTHGUARD_WINDOWS.bat once and wait for “READY”.</small></div>}

    {fetched && <div className="result-card">
      <small>SOURCE DETECTED</small>
      <h2>{fetched.title || "Content fetched successfully"}</h2>
      <p><b>Type:</b> {fetched.source}</p>
      {fetched.text && <details><summary>Text preview</summary><p>{fetched.text.slice(0,2500)}</p></details>}
    </div>}

    {result && <div className={`result-card ${result.tone||"warning"}`}>
      <small>AUTHENTICITY MODEL RESULT · {result.mode?.toUpperCase()}</small>
      <h2>{result.verdict}</h2>
      <div className="big-score">{result.confidence}%</div>
      <p><b>Model:</b> {result.model}</p>
      <h3>Why this result?</h3>
      {(result.reasons||[]).map((x,i)=><p key={i}>✓ {x}</p>)}
      <p className="result-note">
        This result is a model estimate. “Real” means the detector found patterns consistent
        with authentic media; it does not prove that the speaker, claim or source is truthful.
      </p>
    </div>}
  </main>
}
