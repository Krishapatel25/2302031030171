import os
import tempfile
from pathlib import Path
from typing import Any

from .models import text_detector, image_detector, video_detector, audio_detector
from .config import TEXT_MODEL, IMAGE_MODEL, VIDEO_MODEL, AUDIO_MODEL

FAKE_WORDS = ("fake", "false", "spoof", "synthetic", "ai-generated", "deepfake", "ai generated", "ai_generated")
REAL_WORDS = ("real", "true", "bonafide", "bona-fide", "genuine", "authentic", "human")

def _label_kind(label: str):
    s = label.lower().replace("-", "_").replace(" ", "_")
    if any(x.replace("-", "_").replace(" ", "_") in s for x in FAKE_WORDS):
        return "fake"
    if any(x.replace("-", "_").replace(" ", "_") in s for x in REAL_WORDS):
        return "real"
    # The audio model is a binary fake/real classifier. Its common numbered-label
    # convention is LABEL_0=fake, LABEL_1=real.
    if "label_0" in s:
        return "fake"
    if "label_1" in s:
        return "real"
    return None

def _flatten_results(results):
    """Normalize Transformers outputs across pipeline versions.

    Depending on Transformers/task settings, a classifier can return:
      [{"label": ..., "score": ...}]
    or [[{"label": ..., "score": ...}, ...]]
    or a single dict.
    """
    if isinstance(results, dict):
        return [results]
    if not isinstance(results, (list, tuple)):
        return []
    out = []
    for item in results:
        if isinstance(item, dict):
            out.append(item)
        elif isinstance(item, (list, tuple)):
            out.extend(_flatten_results(item))
    return out

def _normalize(results, modality: str, model_name: str):
    """Convert model output into a stable, user-friendly verdict.

    Important: this is an authenticity classifier, not a web fact-checker.
    The explanation therefore describes what the model detected rather than
    inventing factual evidence.
    """
    clean = []
    for x in _flatten_results(results):
        if not isinstance(x, dict) or "label" not in x:
            continue
        try:
            score = float(x.get("score", -1))
        except (TypeError, ValueError):
            continue
        if score >= 0:
            clean.append({**x, "score": score})

    # DeepGuard intentionally returns no_face_detected when an image/video frame
    # has no detectable face. That is a valid forensic outcome, not a server error.
    if not clean:
        raw_items = _flatten_results(results)
        no_face = any(str(x.get("label", "")).lower() == "no_face_detected" for x in raw_items if isinstance(x, dict))
        if no_face:
            return {
                "verdict": "NO FACE DETECTED",
                "confidence": 0.0,
                "tone": "warning",
                "mode": modality,
                "model": model_name,
                "label": "no_face_detected",
                "reasons": [
                    f"The {modality} forensic model could not find a usable face in the supplied media.",
                    "This detector is designed for face-based deepfake analysis, so it will not guess REAL or FAKE when there is no face to inspect.",
                    "Try a clear image/video frame containing a visible face.",
                ],
                "class_scores": {"fake": None, "real": None},
                "raw": raw_items[:5],
            }
        raise RuntimeError("Model returned no usable prediction.")

    fake_scores = [float(x["score"]) for x in clean
                   if _label_kind(str(x["label"])) == "fake"]
    real_scores = [float(x["score"]) for x in clean
                   if _label_kind(str(x["label"])) == "real"]

    if fake_scores or real_scores:
        fake = max(fake_scores, default=0.0)
        real = max(real_scores, default=0.0)
        if fake >= real:
            verdict, tone, confidence, label = "LIKELY FAKE", "danger", fake, "fake"
        else:
            verdict, tone, confidence, label = "LIKELY REAL", "success", real, "real"
    else:
        top = max(clean, key=lambda x: float(x.get("score", 0)))
        label = str(top.get("label", "unknown"))
        confidence = float(top.get("score", 0))
        verdict, tone = f"MODEL LABEL: {label}", "warning"

    confidence = round(max(0.0, min(1.0, confidence)) * 100, 1)

    if label == "fake":
        why = (
            f"The {modality} model found patterns that are more consistent with "
            f"the fake/synthetic class ({confidence}% confidence)."
        )
        action = (
            "Why it is flagged: the model's learned authenticity features "
            "outweighed the real/authentic class."
        )
    elif label == "real":
        why = (
            f"The {modality} model found patterns that are more consistent with "
            f"the real/authentic class ({confidence}% confidence)."
        )
        action = (
            "Why it is marked real: the model's learned authenticity features "
            "outweighed the fake/synthetic class."
        )
    else:
        why = f"The model returned the label '{label}' with {confidence}% confidence."
        action = "Why: the configured model did not expose a recognized fake/real label."

    reasons = [
        why,
        action,
        f"Model: {model_name}",
        f"Confidence: {confidence}%",
        "This is an AI authenticity estimate; it does not by itself prove that a real-world claim is factually true.",
    ]

    # Expose both sides when available so the UI can explain the decision.
    if fake_scores or real_scores:
        reasons.insert(2, f"Class scores — fake: {round(fake*100,1)}%, real: {round(real*100,1)}%.")

    return {
        "verdict": verdict,
        "confidence": confidence,
        "tone": tone,
        "mode": modality,
        "model": model_name,
        "label": label,
        "reasons": reasons,
        "class_scores": {
            "fake": round(fake * 100, 1) if (fake_scores or real_scores) else None,
            "real": round(real * 100, 1) if (fake_scores or real_scores) else None,
        },
        "raw": clean[:5],
    }

def analyze_text(text: str, title: str = ""):
    # The selected RoBERTa model is specifically a fake/real news classifier.
    prompt = f"<title>{title[:500]}<content>{text[:11500]}<end>"
    results = text_detector()(prompt)
    return _normalize(results, "text", TEXT_MODEL)

def analyze_image(path: str):
    results = image_detector()(path, top_k=None)
    return _normalize(results, "image", IMAGE_MODEL)

def analyze_video(path: str):
    results = video_detector()(
        path,
        num_frames=20,
        agg_mode="conf",
        return_frame_scores=True,
    )
    clean = _flatten_results(results)
    out = _normalize(clean, "video", VIDEO_MODEL)
    for x in results:
        if isinstance(x, dict) and "frame_scores" in x:
            out["frame_scores"] = x["frame_scores"]
    return out

def analyze_audio(path: str):
    results = audio_detector()(path, top_k=None)
    return _normalize(results, "voice", AUDIO_MODEL)

def save_upload(data: bytes, suffix: str) -> str:
    fd, path = tempfile.mkstemp(suffix=suffix)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    return path
