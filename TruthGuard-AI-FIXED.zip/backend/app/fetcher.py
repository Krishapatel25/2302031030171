import os
import re
import tempfile
from pathlib import Path
from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup

from .config import MAX_URL_BYTES

YOUTUBE_RE = re.compile(r"(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/shorts/)([A-Za-z0-9_-]{6,})", re.I)
MEDIA_TYPES = {
    "image": ("image/",),
    "video": ("video/",),
    "voice": ("audio/",),
}

def validate_url(url: str):
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("URL must start with http:// or https://")
    return parsed

def _suffix_for(content_type: str, url: str, default: str):
    ext = Path(urlparse(url).path).suffix
    if ext and len(ext) <= 8:
        return ext
    mapping = {
        "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp",
        "image/gif": ".gif", "video/mp4": ".mp4", "video/webm": ".webm",
        "audio/mpeg": ".mp3", "audio/wav": ".wav", "audio/x-wav": ".wav",
        "audio/mp4": ".m4a", "audio/ogg": ".ogg",
    }
    return mapping.get(content_type.split(";")[0].lower(), default)

async def download_media_url(url: str):
    validate_url(url)
    async with httpx.AsyncClient(follow_redirects=True, timeout=45, headers={"User-Agent":"TruthGuard/2.0"}) as c:
        r = await c.get(url)
        r.raise_for_status()
        ctype = r.headers.get("content-type", "").lower()
        kind = next((k for k, prefixes in MEDIA_TYPES.items() if any(ctype.startswith(p) for p in prefixes)), None)
        if not kind:
            return None
        if len(r.content) > MAX_URL_BYTES:
            raise ValueError(f"Remote media is larger than {MAX_URL_BYTES // 1024 // 1024} MB.")
        suffix = _suffix_for(ctype, str(r.url), {"image":".jpg","video":".mp4","voice":".wav"}[kind])
        fd, path = tempfile.mkstemp(suffix=suffix)
        with os.fdopen(fd, "wb") as f:
            f.write(r.content)
        return {"path": path, "mode": kind, "url": str(r.url), "content_type": ctype}

async def fetch_web(url):
    validate_url(url)
    media = await download_media_url(url)
    if media:
        return {"url": url, "source": "direct_media", "media": media}

    async with httpx.AsyncClient(follow_redirects=True, timeout=30, headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/151 Safari/537.36","Accept":"text/html,application/xhtml+xml"}) as c:
        r = await c.get(url)
        r.raise_for_status()
    if "text/html" not in r.headers.get("content-type",""):
        raise ValueError("URL is neither supported media nor a normal HTML webpage.")
    soup=BeautifulSoup(r.text,"html.parser")
    title=soup.title.get_text(" ",strip=True) if soup.title else ""
    og_image = soup.find("meta", property="og:image")
    og_video = soup.find("meta", property="og:video") or soup.find("meta", property="og:video:url")
    for tag in soup(["script","style","noscript","svg","nav","footer","header"]):
        tag.decompose()

    # Prefer semantic article content. If it is missing, use JSON-LD articleBody
    # and then a paragraph fallback. This helps news sites that do not use <article>.
    target = (
        soup.find("article")
        or soup.find("main")
        or soup.find(attrs={"itemprop": "articleBody"})
    )
    text = " ".join(target.stripped_strings) if target else ""

    if len(text) < 100:
        jsonld_parts = []
        for script in soup.find_all("script", type="application/ld+json"):
            try:
                import json
                data = json.loads(script.string or script.get_text())
                stack = data if isinstance(data, list) else [data]
                for obj in stack:
                    if isinstance(obj, dict):
                        body = obj.get("articleBody") or obj.get("text")
                        if isinstance(body, str) and len(body) > 50:
                            jsonld_parts.append(body)
            except Exception:
                continue
        if jsonld_parts:
            text = " ".join(jsonld_parts)

    if len(text) < 100:
        paragraphs = [p.get_text(" ", strip=True) for p in soup.find_all("p")]
        paragraphs = [p for p in paragraphs if len(p) >= 35]
        text = " ".join(paragraphs)

    if len(text) < 100:
        target = soup.body or soup
        text = " ".join(target.stripped_strings)

    # Remove repeated whitespace.
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) < 50:
        raise ValueError(
            "The webpage loaded, but it does not expose enough readable article text. "
            "This site may require JavaScript/login or block automated readers."
        )

    media_hint = (
        og_video.get("content") if og_video else
        (og_image.get("content") if og_image else None)
    )
    return {
        "url": str(r.url),
        "title": title[:500],
        "text": text[:30000],
        "source": "webpage",
        "media_hint": media_hint,
        "content_type": r.headers.get("content-type", ""),
    }

async def fetch_youtube(url):
    m=YOUTUBE_RE.search(url)
    if not m: raise ValueError("Invalid YouTube URL.")
    try:
        from yt_dlp import YoutubeDL
        out_dir = tempfile.mkdtemp(prefix="truthguard_yt_")
        outtmpl = os.path.join(out_dir, "%(id)s.%(ext)s")
        opts = {
            "quiet": True, "no_warnings": True, "noplaylist": True,
            "format": "best[ext=mp4]/best",
            "outtmpl": outtmpl,
            "max_filesize": MAX_URL_BYTES,
        }
        with YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            path = ydl.prepare_filename(info)
        if not os.path.exists(path):
            candidates = list(Path(out_dir).glob(f"{m.group(1)}.*"))
            if not candidates:
                raise ValueError("YouTube video could not be downloaded.")
            path = str(candidates[0])
        return {
            "url": url, "video_id": m.group(1), "title": info.get("title",""),
            "source":"youtube_video", "media":{"path":path,"mode":"video","url":url,"content_type":"video/mp4"}
        }
    except Exception as e:
        raise ValueError(f"YouTube video download failed: {e}") from e
