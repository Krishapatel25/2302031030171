import URLScanner from "./URLScanner";
import { analyzeText, analyzeFile } from "./api";
import React, { useState } from "react";
import { Routes, Route, Link, useLocation, useNavigate } from "react-router-dom";
import {
  ShieldCheck, Menu, X, ArrowRight, Sparkles, ScanText, Image as ImageIcon,
  Video, Mic2, CheckCircle2, Zap, LockKeyhole, BrainCircuit, CircleHelp,
  Github, Linkedin, Mail, Play, Upload, FileCheck2, ShieldAlert
} from "lucide-react";

const navItems = [
  ["Home", "/"],
  ["Detector", "/detector"],
  ["URL Scanner", "/url-scanner"],
  ["How It Works", "/how-it-works"],
  ["Pricing", "/pricing"],
  ["About", "/about"]
];

function Header() {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  return (
    <header className="header">
      <div className="container nav-wrap">
        <Link to="/" className="brand" onClick={() => setOpen(false)}>
          <span className="brand-mark"><ShieldCheck size={20}/></span>
          <span>TruthGuard <b>AI</b></span>
        </Link>

        <nav className={`nav ${open ? "nav-open" : ""}`}>
          {navItems.map(([label, path]) => (
            <Link
              key={path}
              className={location.pathname === path ? "active" : ""}
              to={path}
              onClick={() => setOpen(false)}
            >{label}</Link>
          ))}
          <Link className="mobile-login" to="/login" onClick={() => setOpen(false)}>Login</Link><Link className="mobile-login" to="/signup" onClick={() => setOpen(false)}>Sign Up</Link>
        </nav>

        <div className="nav-actions">
          <Link className="login-link" to="/login">Login</Link><Link className="signup-link" to="/signup">Sign Up</Link>
          <Link className="btn btn-primary btn-small" to="/detector">Try Detector <ArrowRight size={15}/></Link>
        </div>

        <button className="menu-btn" onClick={() => setOpen(!open)} aria-label="Toggle menu">
          {open ? <X/> : <Menu/>}
        </button>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <Link to="/" className="brand footer-brand">
            <span className="brand-mark"><ShieldCheck size={20}/></span>
            <span>TruthGuard <b>AI</b></span>
          </Link>
          <p>AI-powered protection against fake news, manipulated media and deepfakes.</p>
          <div className="socials">
            <a href="#!" aria-label="Github"><Github size={17}/></a>
            <a href="#!" aria-label="LinkedIn"><Linkedin size={17}/></a>
            <a href="mailto:hello@truthguard.ai" aria-label="Email"><Mail size={17}/></a>
          </div>
        </div>
        <div>
          <h4>Product</h4>
          <Link to="/detector">Detector</Link>
          <Link to="/pricing">Pricing</Link>
          <Link to="/how-it-works">How it works</Link>
        </div>
        <div>
          <h4>Company</h4>
          <Link to="/about">About us</Link>
          <a href="#features">Features</a>
          <a href="#contact">Contact</a>
        </div>
        <div>
          <h4>Legal & Support</h4>
          <a href="#privacy">Privacy Policy</a>
          <a href="#terms">Terms of Service</a>
          <a href="#security">Security</a>
          <a href="mailto:support@truthguard.ai">Help Center</a>
        </div>
        <div className="footer-newsletter">
          <h4>Stay Updated</h4>
          <p>Get project updates and AI safety insights.</p>
          <div className="newsletter-box"><input placeholder="Your email"/><button aria-label="Subscribe"><ArrowRight size={15}/></button></div>
          <small>No spam. Unsubscribe anytime.</small>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© 2026 TruthGuard AI. Frontend prototype for academic review.</span>
        <span className="footer-pill"><LockKeyhole size={13}/> Your content stays private</span>
      </div>
    </footer>
  );
}

function Home() {
  const navigate = useNavigate();
  return (
    <>
      <section className="hero">
        <div className="hero-orb orb-one"></div>
        <div className="hero-orb orb-two"></div>
        <div className="container hero-grid">
          <div className="hero-copy">
            <div className="eyebrow"><Sparkles size={14}/> AI-powered content verification</div>
            <h1>Know what’s <span>true</span> before you share.</h1>
            <p>
              TruthGuard AI analyzes text, images, videos and voice to spot misinformation,
              AI-generated media and suspicious manipulation — with an explainable confidence score.
            </p>
            <div className="hero-actions">
              <button className="btn btn-primary" onClick={() => navigate("/detector")}>Analyze Content <ArrowRight size={17}/></button>
              <a className="btn btn-soft" href="#how"><Play size={16}/> See how it works</a>
            </div>
            <div className="trust-row">
              <div><CheckCircle2 size={17}/> Explainable results</div>
              <div><CheckCircle2 size={17}/> Multi-modal</div>
              <div><CheckCircle2 size={17}/> Privacy focused</div>
            </div>
          </div>

          <div className="hero-visual">
            <div className="floating-chip chip-top"><span className="pulse"></span> Live AI analysis</div>
            <div className="news-card">
              <div className="news-card-top">
                <div className="mini-brand"><ShieldCheck size={13}/> TruthGuard</div>
                <span className="scan-dot"></span>
              </div>
              <div className="news-headline">
                <span className="fake-label">SUSPICIOUS</span>
                <h3>Scientists discover an impossible new signal...</h3>
                <p>Our models check source reliability, language patterns, image artifacts and contextual evidence.</p>
              </div>
              <div className="scan-lines">
                <span></span><span></span><span></span>
              </div>
              <div className="score-box">
                <div className="score-ring">92%</div>
                <div>
                  <b>Likely Fake</b>
                  <small>High confidence</small>
                </div>
              </div>
            </div>
            <div className="floating-card card-image"><ImageIcon size={17}/><b>Image</b><span>AI generated</span></div>
            <div className="floating-card card-video"><Video size={17}/><b>Video</b><span>Deepfake scan</span></div>
          </div>
        </div>
      </section>

      <section className="metrics">
        <div className="container metrics-grid">
          <div><b>4</b><span>Content modes</span></div>
          <div><b>AI</b><span>Explainable analysis</span></div>
          <div><b>1–100%</b><span>Confidence score</span></div>
          <div><b>24/7</b><span>Ready to verify</span></div>
        </div>
      </section>

      <section className="section" id="features">
        <div className="container">
          <div className="section-heading">
            <div className="eyebrow">ONE PLATFORM · FOUR SIGNALS</div>
            <h2>Detect more than just fake news.</h2>
            <p>Designed as a future-ready verification platform where multiple AI models can work together.</p>
          </div>
          <div className="feature-grid">
            <Feature icon={<ScanText/>} title="Fake News Detection" text="Analyze articles and posts for misleading claims, suspicious language and unreliable sources." tag="NLP / BERT"/>
            <Feature icon={<ImageIcon/>} title="AI Image Detection" text="Identify synthetic or manipulated images using visual artifact and generation-pattern analysis." tag="Computer Vision"/>
            <Feature icon={<Video/>} title="Deepfake Detection" text="Scan videos for face-swap artifacts, frame inconsistencies and synthetic media patterns." tag="Deep Learning"/>
            <Feature icon={<Mic2/>} title="Voice Authenticity" text="Detect suspicious AI-generated speech and voice-cloning patterns in uploaded audio." tag="Audio AI"/>
          </div>
        </div>
      </section>

      <section className="section lavender" id="how">
        <div className="container split-section">
          <div>
            <div className="eyebrow">HOW IT WORKS</div>
            <h2>From upload to explanation in three simple steps.</h2>
            <div className="steps">
              <Step n="01" title="Choose a content type" text="Text, image, video or voice — select the signal you want to verify."/>
              <Step n="02" title="Run AI analysis" text="The frontend prototype simulates the analysis pipeline and model response."/>
              <Step n="03" title="Understand the result" text="See confidence, reasons, risk indicators and an easy-to-understand verdict."/>
            </div>
          </div>
          <div className="pipeline-card">
            <div className="pipeline-title"><BrainCircuit/> Multimodal AI Pipeline</div>
            <div className="pipeline-node"><span>Input</span><small>Text / Image / Video / Voice</small></div>
            <ArrowRight className="pipeline-arrow"/>
            <div className="pipeline-node active-node"><span>AI Models</span><small>NLP · CV · Audio</small></div>
            <ArrowRight className="pipeline-arrow"/>
            <div className="pipeline-node"><span>Explain</span><small>Score · Evidence · Verdict</small></div>
            <div className="pipeline-footer"><Zap size={15}/> Real-time analysis ready for backend integration</div>
          </div>
        </div>
      </section>

      <section className="section pricing-preview">
        <div className="container">
          <div className="section-heading">
            <div className="eyebrow">SIMPLE SUBSCRIPTIONS</div>
            <h2>Start free. Upgrade when you need more.</h2>
          </div>
          <div className="price-grid">
            <PriceCard name="Free" price="₹0" text="For students & casual checks" features={["10 analyses / month","Text detection","Basic confidence score"]}/>
            <PriceCard popular name="Pro" price="₹299" text="For frequent verification" features={["200 analyses / month","Text + image + video + voice","Detailed explanations","History dashboard"]}/>
            <PriceCard name="Research" price="₹799" text="For advanced projects" features={["Unlimited prototype usage","API-ready architecture","Advanced analytics","Priority support"]}/>
          </div>
          <div className="center"><Link to="/pricing" className="text-link">Compare all plans <ArrowRight size={15}/></Link></div>
        </div>
      </section>

      <section className="cta">
        <div className="container cta-inner">
          <div><div className="eyebrow light">READY TO VERIFY?</div><h2>Don’t trust the post. Check it.</h2><p>Try the interactive frontend detector and explore the future AI pipeline.</p></div>
          <Link className="btn btn-white" to="/detector">Open Detector <ArrowRight size={17}/></Link>
        </div>
      </section>
    </>
  );
}

function Feature({icon,title,text,tag}) {
  return <div className="feature-card"><div className="feature-icon">{icon}</div><span className="feature-tag">{tag}</span><h3>{title}</h3><p>{text}</p><div className="feature-link">Explore <ArrowRight size={14}/></div></div>;
}
function Step({n,title,text}) {
  return <div className="step"><span>{n}</span><div><h3>{title}</h3><p>{text}</p></div></div>;
}
function PriceCard({name,price,text,features,popular}) {
  return <div className={`price-card ${popular ? "popular" : ""}`}>{popular && <div className="popular-badge">MOST POPULAR</div>}<h3>{name}</h3><p>{text}</p><div className="price">{price}<small>/month</small></div>{features.map(x=><div className="price-feature" key={x}><CheckCircle2 size={15}/>{x}</div>)}<Link to="/pricing" className={`btn ${popular ? "btn-primary" : "btn-outline"}`}>Choose {name}</Link></div>;
}

function Detector() {
  const [mode, setMode] = useState("text");
  const [value, setValue] = useState("");
  const [file, setFile] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState(() => {
    try { return JSON.parse(localStorage.getItem("truthguard_history") || "[]"); }
    catch { return []; }
  });

  const modes = [
    ["text", <ScanText/>, "Text / News"],
    ["image", <ImageIcon/>, "Image"],
    ["video", <Video/>, "Video"],
    ["voice", <Mic2/>, "Voice"]
  ];

  const resetInput = () => {
    setValue("");
    setFile(null);
    setResult(null);
    setError("");
    setProgress(0);
  };

  const selectMode = (id) => {
    setMode(id);
    resetInput();
  };

  const runAnalysis = async () => {
    if ((mode === "text" && !value.trim()) || (mode !== "text" && !file)) return;

    setAnalyzing(true);
    setResult(null);
    setError("");
    setProgress(8);

    let current = 8;
    const timer = setInterval(() => {
      current = Math.min(current + Math.floor(Math.random() * 9) + 4, 92);
      setProgress(current);
    }, 350);

    try {
      const next = mode === "text"
        ? await analyzeText(value.trim())
        : await analyzeFile(mode, file);

      clearInterval(timer);
      setProgress(100);
      setResult(next);

      const item = {
        ...next,
        id: Date.now(),
        input: file?.name || value.trim().slice(0, 90),
        createdAt: new Date().toLocaleString()
      };

      setHistory(prev => {
        const updated = [item, ...prev].slice(0, 8);
        localStorage.setItem("truthguard_history", JSON.stringify(updated));
        return updated;
      });
    } catch (err) {
      clearInterval(timer);
      setProgress(0);
      setError(err.message || "Analysis failed. Is the backend running?");
    } finally {
      setAnalyzing(false);
    }
  };

  const onFile = (e) => {
    const selected = e.target.files?.[0];
    if (selected) {
      setFile(selected);
      setValue(selected.name);
      setResult(null);
      setError("");
    }
  };

  const onDrop = (e) => {
    e.preventDefault();
    const dropped = e.dataTransfer.files?.[0];
    if (dropped) {
      setFile(dropped);
      setValue(dropped.name);
      setResult(null);
      setError("");
    }
  };

  const clearHistory = () => {
    localStorage.removeItem("truthguard_history");
    setHistory([]);
  };

  const loadHistory = (item) => {
    setMode(item.mode);
    setValue(item.input || "");
    setFile(null);
    setResult(item);
    window.scrollTo({ top: 120, behavior: "smooth" });
  };

  return (
    <main className="detector-page">
      <div className="container detector-layout">
        <div className="detector-intro">
          <div className="eyebrow"><Sparkles size={14}/> AI-powered detector</div>
          <h1>Verify content before it verifies <span>you.</span></h1>
          <p>TruthGuard now sends your input to the local FastAPI backend, where dedicated open-source models analyze text, images, videos and voice.</p>
          <div className="detector-points">
            <span><CheckCircle2/> Multi-modal</span>
            <span><CheckCircle2/> Real models</span>
            <span><CheckCircle2/> Explainable output</span>
          </div>

          {history.length > 0 && (
            <div className="history-panel">
              <div className="history-head"><div><b>Recent checks</b><small>Saved in this browser</small></div><button onClick={clearHistory}>Clear</button></div>
              <div className="history-list">
                {history.map(item => (
                  <button className="history-item" key={item.id} onClick={() => loadHistory(item)}>
                    <span className={`history-dot ${item.tone || "warning"}`}></span>
                    <span className="history-main"><b>{item.verdict}</b><small>{item.input}</small></span>
                    <strong>{item.confidence}%</strong>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="detector-shell">
          <div className="mode-tabs">
            {modes.map(([id,icon,label]) =>
              <button key={id} className={mode===id ? "selected":""} onClick={()=>selectMode(id)}>
                {icon}{label}
              </button>
            )}
          </div>

          <div className="input-area">
            {mode === "text" ? (
              <div className="text-input-wrap">
                <textarea
                  value={value}
                  onChange={e=>{setValue(e.target.value);setResult(null);setError("")}}
                  placeholder="Paste a news article, social media post or claim here..."
                  maxLength={12000}
                />
                <span className="char-count">{value.length}/12000</span>
              </div>
            ) : (
              <label className="dropzone" onDragOver={e=>e.preventDefault()} onDrop={onDrop}>
                {file?.type?.startsWith("image/")
                  ? <img className="upload-preview" src={URL.createObjectURL(file)} alt="Selected preview"/>
                  : <Upload size={32}/>}
                <b>{file ? file.name : `Upload ${mode} file`}</b>
                <span>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · Ready for model analysis` : "Drag & drop or click to browse"}</span>
                <input
                  type="file"
                  accept={mode==="image"?"image/*":mode==="video"?"video/*":"audio/*"}
                  onChange={onFile}
                />
              </label>
            )}
          </div>

          <div className="input-hint">
            <LockKeyhole size={14}/> Files are sent to your local backend at <b>localhost:8000</b> and are not uploaded to a third-party AI API.
          </div>

          <div className="detector-actions">
            <button
              className="btn btn-primary analyze-btn"
              onClick={runAnalysis}
              disabled={analyzing || (mode==="text" ? !value.trim() : !file)}
            >
              {analyzing ? `Running model ${progress}%` : "Analyze with AI"} <ArrowRight size={16}/>
            </button>
            <button className="btn btn-outline reset-btn" onClick={resetInput} disabled={analyzing}>Reset</button>
          </div>

          {error && <div className="api-error"><ShieldAlert size={16}/><span>{error}</span></div>}

          {analyzing && (
            <div className="analysis-loader">
              <div className="loader-bar"><span style={{width:`${progress}%`}}></span></div>
              <div className="analysis-status">
                <span>Loading model, preprocessing input and running inference...</span>
                <b>{progress}%</b>
              </div>
            </div>
          )}

          {result && <ResultCard result={result}/>}
        </div>
      </div>
    </main>
  );
}

function ResultCard({result}) {
  const copyResult = async () => {
    const text = `TruthGuard AI
Verdict: ${result.verdict}
Confidence: ${result.confidence}%
Model: ${result.model || "N/A"}
Reasons: ${(result.reasons || []).join("; ")}`;
    try { await navigator.clipboard.writeText(text); } catch {}
  };

  const downloadResult = () => {
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `truthguard-result-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const tone = result.tone || "warning";
  return <div className={`result-card ${tone}`}>
    <div className="result-top">
      <div className={`result-icon ${tone}`}>
        {tone==="danger" ? <ShieldAlert/> : tone==="success" ? <CheckCircle2/> : <BrainCircuit/>}
      </div>
      <div>
        <small>REAL MODEL RESULT · {result.mode?.toUpperCase()}</small>
        <h2>{result.verdict}</h2>
      </div>
      <b className="big-score">{result.confidence}%</b>
    </div>

    <div className="score-line"><span style={{width:`${result.confidence}%`}}></span></div>

    <div className="result-summary">
      <span>Confidence</span>
      <b>{result.confidence >= 90 ? "Very high" : result.confidence >= 75 ? "High" : "Moderate"}</b>
    </div>

    <div className="model-name"><b>Model</b><span>{result.model || "Configured backend model"}</span></div>

    <h3>Why this result?</h3>
    {result.class_scores && (
      <div className="model-name">
        <b>Model class scores</b>
        <span>Fake: {result.class_scores.fake ?? "—"}% · Real: {result.class_scores.real ?? "—"}%</span>
      </div>
    )}
    <div className="reason-grid">
      {(result.reasons || []).map((r,i)=>
        <div key={`${r}-${i}`}><CheckCircle2 size={15}/><span>{r}</span></div>
      )}
    </div>

    {result.frame_scores?.length > 0 && (
      <div className="frame-info">
        Video frame analysis: {result.frame_scores.length} sampled frames
      </div>
    )}

    <div className="result-actions">
      <button className="btn btn-soft" onClick={copyResult}><FileCheck2 size={15}/> Copy result</button>
      <button className="btn btn-soft" onClick={downloadResult}><Upload size={15}/> Export JSON</button>
    </div>

    <div className="result-note">
      <LockKeyhole size={14}/> AI output is probabilistic. A fake-news classifier alone cannot establish factual truth; production fact-checking should add source retrieval and evidence verification.
    </div>
  </div>;
}

function Pricing() {
  const plans = [
    {name:"Free",price:"₹0",desc:"Try the core experience",features:["10 analyses / month","Text & social post detection","Basic confidence score","Recent history"]},
    {name:"Pro",price:"₹299",desc:"For regular verification",features:["200 analyses / month","Text, image, video & voice","Detailed explanations","Full history","Priority analysis"],popular:true},
    {name:"Research",price:"₹799",desc:"For students, teams & labs",features:["Unlimited analyses","Advanced analytics","API integration ready","Exportable reports","Priority support"]}
  ];
  return <main className="simple-page"><div className="container"><div className="page-heading"><div className="eyebrow">PRICING</div><h1>A plan for every level of verification.</h1><p>Subscription UI is included now; payment and usage limits can be connected later.</p></div><div className="price-grid pricing-full">{plans.map(p=><PriceCard key={p.name} {...p}/>)}</div><div className="faq"><h2>What comes next?</h2><div className="faq-grid"><div><Zap/>Payment gateway</div><div><BrainCircuit/>AI model usage limits</div><div><FileCheck2/>Reports & exports</div></div></div></div></main>;
}

function About() {
  return <main className="simple-page about-page"><div className="container"><div className="about-hero"><div><div className="eyebrow">ABOUT TRUTHGUARD AI</div><h1>A smarter safety layer for the information age.</h1><p>TruthGuard AI is a proposed multimodal verification platform that brings fake-news detection, AI-image analysis, deepfake detection and voice authenticity into one clean workflow.</p><Link to="/detector" className="btn btn-primary">Explore the prototype <ArrowRight size={16}/></Link></div><div className="brain-art"><BrainCircuit size={120}/><span>AI</span></div></div><div className="about-grid"><div><h2>Our vision</h2><p>Make content verification understandable, accessible and explainable — not just a black-box “real or fake” label.</p></div><div><h2>Research direction</h2><p>NLP, transformer models, computer vision, deepfake forensics, audio analysis, source credibility and explainable AI can power the future backend.</p></div><div><h2>Privacy first</h2><p>Uploaded content should be processed securely, with clear retention controls and no unnecessary data sharing.</p></div></div><div className="about-banner"><ShieldCheck/><div><h3>Built as a modular academic project</h3><p>The frontend is intentionally API-ready so model integration can happen incrementally during later reviews.</p></div></div></div></main>;
}

function HowItWorks() {
  return <main className="simple-page"><div className="container"><div className="page-heading"><div className="eyebrow">ARCHITECTURE</div><h1>One interface. Multiple AI signals.</h1><p>This is the frontend story you can present in your review while the backend models are developed in phases.</p></div><div className="architecture"><Arch n="01" title="User input" text="Article, social post, image, video or voice file."/><Arch n="02" title="Pre-processing" text="Clean text, extract frames, normalize media and prepare model inputs."/><Arch n="03" title="AI inference" text="NLP + computer vision + audio/deepfake models return predictions."/><Arch n="04" title="Explainable result" text="Confidence, risk indicators, reasons and references are presented to the user."/></div></div></main>;
}
function Arch({n,title,text}) { return <div className="arch-card"><span>{n}</span><div><h3>{title}</h3><p>{text}</p></div><ArrowRight/></div>; }

function Login() {
  return <main className="auth-page"><div className="auth-card"><div className="auth-logo"><span className="brand-mark"><ShieldCheck size={20}/></span><b>TruthGuard AI</b></div><h1>Welcome back.</h1><p>Sign in to access your verification history and subscription.</p><form onSubmit={e=>e.preventDefault()}><label>Email<input type="email" placeholder="you@example.com"/></label><label>Password<input type="password" placeholder="••••••••"/></label><div className="form-row"><label className="remember"><input type="checkbox"/> Remember me</label><Link to="/forgot-password">Forgot password?</Link></div><button className="btn btn-primary full">Sign in <ArrowRight size={16}/></button></form><div className="or"><span>or</span></div><button className="google-btn">Continue with Google</button><p className="auth-foot">New here? <Link to="/pricing">Choose a plan</Link></p></div></main>;
}


function Signup() {
  return <main className="auth-page"><div className="auth-card">
    <div className="auth-logo"><span className="brand-mark"><ShieldCheck size={20}/></span><b>TruthGuard AI</b></div>
    <h1>Create your account.</h1>
    <p>Join TruthGuard AI and start verifying digital content safely.</p>
    <form onSubmit={e=>e.preventDefault()}>
      <label>Full Name<input type="text" placeholder="Your name"/></label>
      <label>Email<input type="email" placeholder="you@example.com"/></label>
      <label>Password<input type="password" placeholder="Create a password"/></label>
      <label>Confirm Password<input type="password" placeholder="Repeat your password"/></label>
      <label className="terms-check"><input type="checkbox"/> I agree to the Terms & Privacy Policy</label>
      <button className="btn btn-primary full">Create Account <ArrowRight size={16}/></button>
    </form>
    <div className="or"><span>or</span></div>
    <button className="google-btn">Continue with Google</button>
    <p className="auth-foot">Already have an account? <Link to="/login">Sign in</Link></p>
  </div></main>;
}

function ForgotPassword() {
  return <main className="auth-page"><div className="auth-card">
    <div className="auth-logo"><span className="brand-mark"><ShieldCheck size={20}/></span><b>TruthGuard AI</b></div>
    <h1>Reset your password.</h1>
    <p>Enter your email and we’ll send instructions to reset your password.</p>
    <form onSubmit={e=>e.preventDefault()}>
      <label>Email<input type="email" placeholder="you@example.com"/></label>
      <button className="btn btn-primary full">Send Reset Link <ArrowRight size={16}/></button>
    </form>
    <p className="auth-foot"><Link to="/login">← Back to login</Link></p>
  </div></main>;
}

function App() {
  return <><Header/><Routes><Route path="/" element={<Home/>}/><Route path="/detector" element={<Detector/>}/><Route path="/url-scanner" element={<URLScanner/>}/><Route path="/pricing" element={<Pricing/>}/><Route path="/about" element={<About/>}/><Route path="/how-it-works" element={<HowItWorks/>}/><Route path="/login" element={<Login/>}/><Route path="/signup" element={<Signup/>}/><Route path="/forgot-password" element={<ForgotPassword/>}/></Routes><Footer/></>;
}

export default App;