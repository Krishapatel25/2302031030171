import os
import shutil
import traceback
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from .config import ALLOWED_ORIGINS, ALLOWED_ORIGIN_REGEX, MAX_FILE_BYTES
from .fetcher import fetch_web, fetch_youtube

app = FastAPI(
    title="TruthGuard AI API",
    version="2.1.0",
    description="Multimodal fake-news and synthetic-media analysis API.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_origin_regex=ALLOWED_ORIGIN_REGEX,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Safety net: NOTHING should ever reach the browser as an empty/blank 500.
# Any exception we didn't already turn into an HTTPException lands here and
# still gets a real, readable JSON message with the full traceback.
@app.exception_handler(Exception)
async def catch_all(request: Request, exc: Exception):
    tb = traceback.format_exc()
    print(tb)  # full traceback still goes to the backend console/log too
    return JSONResponse(
        status_code=500,
        content={"detail": f"{type(exc).__name__}: {exc}", "traceback": tb.splitlines()[-8:]},
    )

class TextRequest(BaseModel):
    text: str
    title: str = ""

@app.get("/")
def root():
    return {"status":"ok","service":"truthguard-ai-api","health":"/health"}

@app.get("/health")
def health():
    return {"status":"ok","service":"truthguard-ai-api","version":"2.2.0"}

@app.get("/health/models")
def health_models():
    # Do not load the large models during health checks. This endpoint only
    # reports whether the Python dependencies are importable.
    checks = {}
    for name, mod in (("transformers", "transformers"), ("torch", "torch"), ("PIL", "PIL"), ("cv2", "cv2"), ("librosa", "librosa"), ("deepguard", "deepguard"), ("ultralytics", "ultralytics")):
        try:
            __import__(mod)
            checks[name] = "ok"
        except Exception as exc:
            checks[name] = f"error: {type(exc).__name__}: {exc}"
    return {"status": "ok" if all(v == "ok" for v in checks.values()) else "degraded", "checks": checks}

@app.post("/api/analyze/text")
def analyze_text_endpoint(body: TextRequest):
    text = body.text.strip()
    if len(text) < 10:
        raise HTTPException(400, "Please provide at least 10 characters.")
    if len(text) > 12000:
        raise HTTPException(400, "Text is too long. Maximum is 12,000 characters.")
    try:
        from .inference import analyze_text
        return analyze_text(text, body.title)
    except Exception as e:
        raise HTTPException(500, f"Text model error: {type(e).__name__}: {e}")

def save_upload_safe(data: bytes, suffix: str) -> str:
    # Local copy of inference.save_upload that never triggers a torch/
    # transformers import, so a broken AI-library install can't stop us
    # from at least saving the file and reporting a clear error.
    import tempfile
    fd, path = tempfile.mkstemp(suffix=suffix)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    return path

async def _read_upload(file: UploadFile):
    data = await file.read()
    if not data:
        raise HTTPException(400, "Uploaded file is empty.")
    if len(data) > MAX_FILE_BYTES:
        raise HTTPException(413, f"File is larger than {MAX_FILE_BYTES // 1024 // 1024} MB.")
    return data

@app.post("/api/analyze/image")
async def analyze_image_endpoint(file: UploadFile = File(...)):
    data = await _read_upload(file)
    path = save_upload_safe(data, Path(file.filename or "image.jpg").suffix or ".jpg")
    try:
        from .inference import analyze_image
        return analyze_image(path)
    except Exception as e:
        raise HTTPException(500, f"Image model error: {type(e).__name__}: {e}")
    finally:
        try: os.remove(path)
        except OSError: pass

@app.post("/api/analyze/video")
async def analyze_video_endpoint(file: UploadFile = File(...)):
    data = await _read_upload(file)
    path = save_upload_safe(data, Path(file.filename or "video.mp4").suffix or ".mp4")
    try:
        from .inference import analyze_video
        return analyze_video(path)
    except Exception as e:
        raise HTTPException(500, f"Video model error: {type(e).__name__}: {e}. Check that deepguard, ultralytics and the model weights are installed.")
    finally:
        try: os.remove(path)
        except OSError: pass

@app.post("/api/analyze/voice")
async def analyze_voice_endpoint(file: UploadFile = File(...)):
    data = await _read_upload(file)
    path = save_upload_safe(data, Path(file.filename or "audio.wav").suffix or ".wav")
    try:
        from .inference import analyze_audio
        return analyze_audio(path)
    except Exception as e:
        raise HTTPException(500, f"Voice model error: {type(e).__name__}: {e}")
    finally:
        try: os.remove(path)
        except OSError: pass

async def _analyze_fetched_media(media):
    from .inference import analyze_image, analyze_video, analyze_audio
    path = media["path"]
    try:
        if media["mode"] == "image": return analyze_image(path)
        if media["mode"] == "video": return analyze_video(path)
        if media["mode"] == "voice": return analyze_audio(path)
        raise ValueError("Unsupported media mode.")
    finally:
        try: os.remove(path)
        except OSError: pass
        parent = Path(path).parent
        if parent.name.startswith("truthguard_yt_"):
            shutil.rmtree(parent, ignore_errors=True)

@app.post("/api/analyze-url")
async def analyze_url_endpoint(body: dict):
    url = str(body.get("url","")).strip()
    if not url:
        raise HTTPException(400, "URL is required.")
    try:
        fetched = await (fetch_youtube(url) if ("youtube.com/" in url.lower() or "youtu.be/" in url.lower()) else fetch_web(url))
        result = None
        if fetched.get("media"):
            result = await _analyze_fetched_media(fetched["media"])
        elif fetched.get("text"):
            from .inference import analyze_text
            result = analyze_text(fetched["text"][:12000], fetched.get("title",""))
        else:
            raise ValueError("URL was reached, but no analyzable text or media was found. The site may require JavaScript/login, block automated access, or provide only an unsupported page.")
        result["input_url"] = url
        result["source_type"] = fetched.get("source")
        result["title"] = fetched.get("title","")
        return {"fetched": {k:v for k,v in fetched.items() if k != "media"}, "result": result}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))
