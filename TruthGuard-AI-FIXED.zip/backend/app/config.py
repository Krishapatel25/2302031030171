import os

ALLOWED_ORIGINS = [
    x.strip() for x in os.getenv(
        "ALLOWED_ORIGINS",
        "http://localhost:5173,http://localhost:5174,http://127.0.0.1:5173,http://127.0.0.1:5174"
    ).split(",") if x.strip()
]
ALLOWED_ORIGIN_REGEX = r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$"

MAX_FILE_MB = int(os.getenv("MAX_FILE_MB", "100"))
MAX_FILE_BYTES = MAX_FILE_MB * 1024 * 1024
MAX_URL_MB = int(os.getenv("MAX_URL_MB", "200"))
MAX_URL_BYTES = MAX_URL_MB * 1024 * 1024

TEXT_MODEL = "hamzab/roberta-fake-news-classification"
DEEPFAKE_MODEL = "KoreaPeter/ms-eff-gcvit-deepfake-b0-celeb-df-v2"
VIDEO_MODEL = DEEPFAKE_MODEL
IMAGE_MODEL = DEEPFAKE_MODEL
AUDIO_MODEL = "Hemgg/Deepfake-audio-detection"
