# TruthGuard AI — Real Model Backend

FastAPI backend for the TruthGuard AI frontend.

## Models

- Text: `hamzab/roberta-fake-news-classification`
- Image: `KoreaPeter/ms-eff-gcvit-b0-celeb-df-v2`
- Video: `KoreaPeter/ms-eff-gcvit-b0-celeb-df-v2`
- Voice: `Hemgg/Deepfake-audio-detection`

The first request downloads the selected model from Hugging Face and caches it locally.

## Setup

Python 3.10+ is recommended.

```bash
cd backend
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Then:

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

API:
- `GET http://localhost:8000/health`
- `POST /api/analyze/text`
- `POST /api/analyze/image`
- `POST /api/analyze/video`
- `POST /api/analyze/voice`

## Important

These are research/open-source classifiers. Their benchmark scores do **not** mean the system can guarantee that real-world content is true or fake. In particular, a fake-news classifier is not the same thing as a fact-checking engine. For a production fact-checking product, add retrieval/source verification and claim-level evidence before presenting a definitive verdict.
